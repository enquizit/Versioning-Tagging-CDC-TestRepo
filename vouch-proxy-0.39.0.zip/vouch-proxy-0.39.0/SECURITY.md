# Security Policy

## Reporting a Vulnerability

If you have discovered a vulnerability in Vouch Proxy DO NOT post an issue on GitHub.

Please do email the maintainers at vouch-proxy-security@bnf.net

We will respond in short order (usually within a day or two).
